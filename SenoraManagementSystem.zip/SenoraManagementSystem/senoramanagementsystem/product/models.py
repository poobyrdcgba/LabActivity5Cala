from django.db import models

# Create your models here.

class Product(models.Model):
    ProductName = models.CharField(max_length=20)
    Price = models.DecimalField(max_digits=7, decimal_places=2)

class ProductTransaction(models.Model):
    ClientID = models.ForeignKey('user.Client', on_delete=models.CASCADE)
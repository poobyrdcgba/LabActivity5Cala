from django.db import models


# Create your models here.

class ClientRequest(models.Model):
    ClientID = models.ForeignKey("user.Client", on_delete=models.CASCADE)
    ServiceID = models.ForeignKey("bookings.Service", on_delete=models.CASCADE)
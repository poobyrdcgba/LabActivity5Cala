from django.db import models



# Create your models here.

class Appointment(models.Model):
    StaffID = models.ForeignKey('user.Staff', on_delete=models.CASCADE)
    ClientID = models.ForeignKey('user.Client', on_delete=models.CASCADE)
    Date = models.DateField(blank=False)
    Time = models.TimeField(blank=False)
    Status = models.CharField(max_length=20)
    TotalAmount = models.DecimalField(max_digits=7,decimal_places=2)

class Service(models.Model):
    ServiceName = models.CharField(max_length=20)
    Price = models.DecimalField(max_digits=7,decimal_places=2)
    Appointment = models.ManyToManyField(Appointment, through="AppointmentService")

class AppointmentService(models.Model):
    AppointmentID = models.ForeignKey(Appointment, on_delete=models.CASCADE)
    ServiceID = models.ForeignKey(Service, on_delete=models.CASCADE)
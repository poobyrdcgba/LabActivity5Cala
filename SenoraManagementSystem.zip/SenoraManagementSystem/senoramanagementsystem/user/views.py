from django.http import HttpResponse
from django.shortcuts import render
from django.views import View
from .form import ClientForm

# Create your views here.


def index(request):
    return HttpResponse("hello world")


class ClientRegistrations(View):
    template = 'reg.html'

    def get(self,request):
        client = ClientForm
        return render(request, self.template, {'form': client})

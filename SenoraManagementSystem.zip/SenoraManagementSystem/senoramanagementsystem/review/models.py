from django.db import models




# Create your models here.

class Review(models.Model):
    ClientID = models.ForeignKey('user.Client', on_delete=models.CASCADE)
    ServiceID = models.ForeignKey('bookings.Service', on_delete=models.CASCADE)
    RatingChoices = (('1', '1 Star'),('2', '2 Stars'),('3', '3 Stars'),('4', '4 Stars'),('5', '5 Stars'),)
    Rating = models.CharField(max_length=1,choices=RatingChoices)
    ReviewParagraph = models.CharField(max_length=100)
from django.db import models

# Create your models here.


class Person(models.Model):
    #
    UserName = models.CharField(max_length=20)
    Password = models.CharField(max_length=20)
    #
    FirstName = models.CharField(max_length=20)
    LastName = models.CharField(max_length=20)
    ContactNumber = models.CharField(max_length=20)
    Email = models.CharField(max_length=20)


class Client(Person):

    Address = models.CharField(max_length=30)


class Staff(Person):

    Position = models.CharField(max_length=20)

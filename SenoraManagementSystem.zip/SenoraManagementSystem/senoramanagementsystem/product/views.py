from django.http import HttpResponse
from django.shortcuts import render
from django.contrib import messages
from django.template import loader
from django.views import View
from .forms import ClientForm
from senoramanagementsystem.user.models import Client, Person

# Create your views here.

def login(request):
    message = ""
    if request.method == "GET":
        print(request.GET)
        if request.GET:
            username = request.GET['Uname']
            password = request.GET['Pass']
            query = Person.objects.filter(Username=username, Password=password)
            if not query:
                message = "Username or password incorrect"
            else:
                message = "successful"
    return render(request, "login.html", {'message':message})

def registration(request):
    if request.method == "POST":
        new_client = ClientForm(request.POST)
        if new_client.is_valid():
            new_client.save()
    form = ClientForm
    return render(request, "regi.html", {'form':form})

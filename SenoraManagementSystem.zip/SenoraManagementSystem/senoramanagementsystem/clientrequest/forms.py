from django.forms import ModelForm
from django import forms
from user.models import Staff


class ClientForm(ModelForm):

    class Meta:
        model = Staff
        fields = "__all__"

from django.contrib import admin
#from user.models import Client
#from models import Product, ProductTransaction
# Register your models here.
#admin.site.register(Client)
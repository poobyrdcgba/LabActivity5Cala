from django.urls import path
from . import views
app_name = 'user'
urlpatterns = [
    path('', views.index, name='index'), #127.0.0.1/user
    path('reg', views.ClientRegistrations.as_view(), name='reg'),

]
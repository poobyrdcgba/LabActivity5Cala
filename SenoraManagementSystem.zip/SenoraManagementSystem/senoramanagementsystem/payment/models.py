from django.db import models




# Create your models here.

class Payment(models.Model):
    ClientID = models.ForeignKey("user.Client", on_delete=models.CASCADE)
    AppointmentID = models.ForeignKey("bookings.Appointment", on_delete=models.CASCADE)
    Date = models.DateField(blank=False)
    Time = models.TimeField(blank=False)
    Amount = models.DecimalField(max_digits=7,decimal_places=2)